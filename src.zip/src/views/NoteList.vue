<!--  frontend/src/components/NoteList.vue  -->


<template>
     <div class="title">
            <span style="font-size: 28px; color: #272727;  font-weight: bold;">Triangle.Message</span>
            <span style="font-size: 16px; color: #f60c3e;  font-weight: bold;">&nbsp;&nbsp;■&nbsp;&nbsp;</span>
            <span style="font-size: 29px; color: #272727;  font-weight: bold;">一些留言</span>
    </div>

    <div class="list">
        <template v-for="note in info" v-bind:key="note.url" >
           
            <div :style="gridStyle(note)" class="note">
                    <div class="inner">

                        <div v-if="note.user!=null" class="name">
                            <span  style="border-bottom: 3px solid #f60c3e;font-size:large;">
                                {{ note.user.username }}
                            </span>
                        </div>
                  
                        <router-link
                                :to="{ name: 'NoteDetail', params: { id: note.id }}"
                                class="note-content" :style="noteStyle(note)"
                        >
                            {{ note.text }}
                        </router-link>
                        <div style="display: flex;">
                            <div class="like">
                            <router-link :to="{ name: 'Developing' }">
                                <n-button text text-color="#CCCCCC" class="like_btn">
                                    <n-icon size="16">
                                    <pen-icon />
                                    </n-icon>
                                    <span>{{ note.likes }}</span>
                                </n-button>
                            </router-link>
                        </div>
                        <div class="time">{{ formatted_time(note.created) }}</div>
                        </div>
                        
                        
                    </div>
                    
            </div>
         

        </template>
    </div>





</template>

<script>
   import {ref} from 'vue'
   import {useRoute} from 'vue-router'
   import getNoteData from '@/composables/getNoteData.js'
   import pagination from '@/composables/pagination.js'
   import noteGrid from '@/composables/noteGrid.js'
   import formattedTime from '@/composables/formattedTime.js'
   import noteText from '@/composables/noteText.js'
   import { NIcon, NButton } from "naive-ui";
    import {
        Heart as PenIcon,
    } from "@vicons/ionicons5";

   export default {
       name: 'NoteList',
       components: {
        NButton, PenIcon, NIcon,
    },
       setup() {
           const info = ref('');
           const route = useRoute();

           const kwargs = ref({page: 0, searchText: ''});
           getNoteData(info, route, kwargs);

           const {
               is_page_exists,
               get_page_param,
               get_path
           } = pagination(info, route);

           const {

               gridStyle
           } = noteGrid();
           const {
                noteStyle
           } = noteText();

           const formatted_time = formattedTime;

           return {
               info,
               is_page_exists,
               get_page_param,
               get_path,
               noteStyle,
               gridStyle,
               formatted_time,
           }
       },
   }

</script>

<!-- "scoped" 使样式仅在当前组件生效 -->
<style scoped>

    .title {
        position: absolute;
        top: 10px;
        left: 181px;
        padding-top: 45px;
        padding-bottom: 35px;
        padding-left: 50px;
        

        width: auto;
    }



    .note{

        border-top: 1px dotted #DDDDDD;
        padding-top: 32px;
        padding-bottom: 22.4px;
        flex-grow: 1; 
        max-width:100%;
    }

    .inner{
        padding-left: 32px;
        padding-right: 32px;
        border-right: 1px dotted #DDDDDD;
    }

    
 

   .list{
    position: absolute; 
    top: 142px;  
    left: 181px; 
    width: 1300px;
    display: flex; flex-wrap: wrap;
    margin-left: 15px;
   }

   .note-content {
    display: block;
       color: black;
       text-decoration: none;
       max-width: 100%;
   }


   .name{
    margin-bottom: 7px; 
   }


   .time{
    font-size: small;
    margin-top: 20px;
    margin-left: 50px;
    color: #FFFFFF;
   }
   
   .note:hover .time{

    font-size: small;
    color: #AAAAAA;
   }

   .like{
    margin-right: 5px;
    margin-top: 20px;

   }
   .like_btn:hover {
  
    color: #f60c3e;
   }
</style>

