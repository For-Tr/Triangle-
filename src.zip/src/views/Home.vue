<!--  frontend/src/views/Home.vue  -->

<template>

    


        <NoteList/>


    

</template>

<script>
    import NoteList from '@/views/NoteList.vue'

    export default {
        name: 'Home',
        components: { NoteList}
    }
</script>

