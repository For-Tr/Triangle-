<template>

    <div id="note-create">
        <div class="title">
            <span style="font-size: 28px; color: #272727;  font-weight: bold;">Trans.Wrrite</span>
            <span style="font-size: 16px; color: #f60c3e;  font-weight: bold;">&nbsp;&nbsp;■&nbsp;&nbsp;</span>
            <span style="font-size: 29px; color: #272727;  font-weight: bold;">留下诗意</span>
        </div>
        

        <div id="list">
            <form>
                <div class="form-elem">
                    <span>正文：</span>
                    <textarea v-model="body" placeholder="输入正文" rows="20" cols="80"></textarea>
                </div>

                <div class="form-elem">
                    <button v-on:click.prevent="submit">提交</button>
                </div>
            </form>
        </div>

    </div>

</template>

<script>

    import axios from 'axios';
    import authorization from '@/utils/authorization';


    export default {
        name: 'NoteCreate',

        data: function () {
            return {
                body: '',
            }
        },
        methods: {
            // 点击提交按钮
            submit() {
                const that = this;
                authorization()
                    .then(function (response) {
                            if (response[0]) {

                                let data = {
                                    body: that.body,
                                };

                                // 发送发表文章请求
                                // 成功后前往详情页面
                                const token = localStorage.getItem('access.myblog');
                                axios
                                    .post('/api/notes/',
                                        data,
                                        {
                                            headers: {Authorization: 'Bearer ' + token}
                                        })
                                    .then(function (response) {
                                        that.$router.push({name: 'NoteDetail', params: {id: response.data.id}});
                                    })
                            }
                            else {
                                alert('令牌过期，请重新登录。')
                            }
                        }
                    )
            }
        }
    }
</script>

<style scoped>
    .title{
        position: absolute;
        top: 60px;
        left: 200px;
    }
    
    #list{
    position: absolute; 
    top: 142px;  
    left: 181px; 
    display: flex; flex-wrap: wrap;
    margin-left: 15px;
   }

    #note-create {
        text-align: center;
        font-size: large;
    }

    form {
        text-align: left;
        padding-left: 230px;
        padding-right: 10px;
    }

    .form-elem {
        padding: 10px;
    }

    input {
        height: 25px;
        padding-left: 10px;
        width: 50%;
    }

    button {
        height: 35px;
        cursor: pointer;
        border: none;
        outline: none;
        background: steelblue;
        color: whitesmoke;
        border-radius: 5px;
        width: 60px;
    }
</style>