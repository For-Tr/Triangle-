<!-- frontend/src/views/Login.vue -->

<template>

<div class="title">
            <span style="font-size: 28px; color: #272727;  font-weight: bold;">Trans.Members</span>
            <span style="font-size: 16px; color: #f60c3e;  font-weight: bold;">&nbsp;&nbsp;■&nbsp;&nbsp;</span>
            <span style="font-size: 29px; color: #272727;  font-weight: bold;">会员订阅</span>
    </div>
<div class="list">
    <div id="grid">
        <div id="signup">
            <h3>注册账号</h3>
            <form>
                <div class="form-elem">
                    <span>用户名：</span> 
                    <input v-model="signupName" type="text" placeholder="输入用户名">
                </div>
                <div class="form-elem">
                    <span>邮箱：</span> 
                    <input v-model="email" type="email" placeholder="输入邮箱">
                </div>
                <div class="form-elem">
                    <span>密码：</span> 
                    <input v-model="signupPwd" type="password" placeholder="输入密码">
                </div>
                <div class="form-elem">
                    <span>确认密码：</span> 
                    <input v-model="RePwd" type="password" placeholder="确认密码">
                </div>
                <div class="form-elem">
                    <button v-on:click.prevent="signup">提交</button>
                </div>
            </form>
        </div>

       
    </div>
</div>


</template>

<script>
    import axios from 'axios';


    export default {
        name: 'Login',
        data: function () {
            return {
                signupName: '',
                email: '',
                signupPwd: '',
                RePwd: '',
                signupResponse: null,
            }
        },
        methods: {
            signup() {
                const that = this;
                axios
                    .post('/api/user/', {
                        username: this.signupName,
                        email: this.email,
                        password: this.signupPwd,
                        repassword: this.RePwd,
                    })
                    .then(function (response) {
                        that.signupResponse = response.data;
                        alert('验证邮件已发送，请验证后登录');
                    })
                    .catch(function (error) {
                        alert(error.message);
                        // Handling Error here...
                        // https://github.com/axios/axios#handling-errors
                    });
            },
        }
    }
</script>

<style scoped>
    #grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
    }
    #signup {
        text-align: center;
    }
    .form-elem {
        padding: 10px;
    }
    input {
        height: 25px;
        padding-left: 10px;
    }
    button {
        height: 35px;
        cursor: pointer;
        border: none;
        outline: none;
        background: gray;
        color: whitesmoke;
        border-radius: 5px;
        width: 60px;
    }
     #signin {
        text-align: center;
    }


    .title {
        position: absolute;
        top: 10px;
        left: 181px;
        padding-top: 45px;
        padding-bottom: 35px;
        padding-left: 50px;
        

        width: auto;
    }

    .list{
    position: absolute; 
    top: 142px;  
    left: 181px; 
    width: 1300px;
    display: flex; flex-wrap: wrap;
    margin: 300px;
    margin-top: 50px
   }

</style>