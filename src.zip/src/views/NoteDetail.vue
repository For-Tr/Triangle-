<!--  frontend/src/views/NoteDetail.vue  -->

<template>
<div class="title">
            <span style="font-size: 28px; color: #272727;  font-weight: bold;">Trans.Message</span>
            <span style="font-size: 16px; color: #f60c3e;  font-weight: bold;">&nbsp;&nbsp;■&nbsp;&nbsp;</span>
            <span  v-if="notes !== null" style="font-size: 29px; color: #272727;  font-weight: bold;">{{ notes.user.username }}的留言</span>
    </div>

<div class="list">
    <div v-if="notes !== null" class="grid-container">
        <div>
            <a id="title">{{ notes.text }}</a>
            <p id="subtitle">
                本文由 {{ notes.user.username }} 发布于 {{ formatted_time(notes.created) }}
            </p>
            <div v-html="notes.body_html" class="notes-body"></div>
        </div>
        
    </div>
</div>


</template>

<script>


    import axios from 'axios';


    export default {
        name: 'NoteDetail',

        data: function () {
            return {
                notes: null
            }
        },
        mounted() {
            axios
                .get('/api/notes/' + this.$route.params.id)
                .then(response => (this.notes = response.data))
        },
        methods: {
            formatted_time: function (iso_date_string) {
                const date = new Date(iso_date_string);
                return date.toLocaleDateString()
            }
        }
    }
</script>


<style scoped>
    .title {
        position: absolute;
        top: 10px;
        left: 181px;
        padding-top: 45px;
        padding-bottom: 35px;
        padding-left: 50px;
        

        width: auto;
    }

    .grid-container {
        display: grid;
        grid-template-columns: 3fr 1fr;
    }


    #title {
        text-align: center;
        font-size: x-large;
    }

    #subtitle {
        text-align: center;
        color: gray;
        font-size: small;
    }

    .list{
    position: absolute; 
    top: 142px;  
    left: 181px; 
    width: 1300px;
    display: flex; flex-wrap: wrap;
    margin-left: 15px;
   }


</style>

