<!--  frontend/src/App.vue  -->

<template>

    <BlogHeader/>

   
    
    <div class="menu">
        <Menu/>
    </div>

    <router-view/>

    <BlogFooter/>
</template>

<script>
    import BlogHeader from '@/components/BlogHeader.vue'
    import BlogFooter from '@/components/BlogFooter.vue'
    import Menu from '@/components/Menu.vue'

    export default {
        name: 'App',
        components: {BlogHeader,  BlogFooter, Menu}
    }
</script>

<style scoped>
  

    #app {
        font-family: Georgia, Arial, sans-serif;
    }



    .menu{
    position: fixed;
    left: 10px;
    top: 10px;
    border-style: dotted;
    border-color: #DDDDDD;
    border-width: 1px;
    width: 170px;
    height: 720px;
}
</style>