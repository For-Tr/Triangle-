export default function noteGrid() {


    const gridStyle = (note) => {
        return _gridStyle(note)
    };

    return {

        gridStyle,
    }
}

const calculateWidth = (text) => {  
  if(text.length>=300)
    return `75%`;  
  else if(text.length>=100)
    return '70%';
  else if(text.length>=40)
    return '50%';
  return 'auto';

  };
  
  function _gridStyle(note) {
    const width = calculateWidth(note.text);
  
    return {
      width: width,
    };
  }