export default function noteGrid() {

    const noteStyle = (note) => {
        return _noteStyle(note)
    };

    return {

        noteStyle,
    }
}



const calculateFontSize = (text) => {  

  
  const fontSizeMap = [  
    
    { length: 15, size: 40 },  
    { length: 50, size: 30 },  
    { length: 100, size: 19 },  
    { length: 300, size:  16},  
    { length: 500, size: 13 },  
    { length: Infinity, size: 10 } // 设置一个较大的值作为最大字体大小，以确保其他长度都能找到对应的区间  
  ];  
  
  const textLength = text.length;  
  for (let i = 0; i < fontSizeMap.length; i++) {  
    if (textLength <= fontSizeMap[i].length) {  
      return `${fontSizeMap[i].size}px`; // 返回带有单位的字体大小  
    }  
  }  
};
  
  function _noteStyle(note) {
    const fontSize = calculateFontSize(note.text);
  
    return {
      fontSize: fontSize
    };
  }