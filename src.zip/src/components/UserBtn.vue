<template>
    <div class="top-right">
        <n-dropdown :options="options">
            <button color="#EFEFEF" text-color=" #272727" class="btn">
              <n-icon color="#272727" size="16">
                <div class="iperson">
                 <person-icon />
                </div>
              </n-icon>
              &nbsp;个人中心
            </button>
        </n-dropdown>
    </div>
  </template>
  
  <script>
  import { h } from "vue";
  import {
    PersonCircleOutline as UserIcon,
    Pencil as EditIcon,
    LogOutOutline as LogoutIcon,
    PersonSharp as PersonIcon
  } from "@vicons/ionicons5";
  import { NDropdown , NIcon} from "naive-ui";
  
  const renderIcon = (icon) => {
    return () => {
      return h(NIcon, null, {
        default: () => h(icon)
      });
    };
  };
  
  export default{
    setup() {
      return {
        options: [
          {
            label: "用户资料",
            key: "profile",
            icon: renderIcon(UserIcon)
          },
          {
            label: "编辑用户资料",
            key: "editProfile",
            icon: renderIcon(EditIcon)
          },
          {
            label: "退出登录",
            key: "logout",
            icon: renderIcon(LogoutIcon)
          }
        ]
      };
    },
    components: {
        NDropdown, PersonIcon, NIcon
    }
  };
  </script>


<style scoped>
.top-right {
  position: absolute;
  top: 11px;
  right: 11px;
}

.top-right:hover .btn {
  background-color: #f60c3e;
  color: white;
  cursor: pointer;
}

.top-right:hover .iperson {
  color: white;
}

.btn{
  width: 93px;
  height: 33px;
  border: none;
  font-size: small;
  font-weight: 900;
  display: flex;
  align-items: center;

}
</style>