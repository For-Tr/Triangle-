<template>
    <div class="top-righ-reg">
        <n-dropdown :options="options">
          <router-link to="/members" class="login-link">
            <button color="#EFEFEF" text-color=" #272727" class="bn-reg">
              注册
            </button>
          </router-link>
        </n-dropdown>
    </div>
  </template>
  
  <script>

  import { NDropdown, } from "naive-ui";

  export default{
    
    components: {
        NDropdown,
    }
  };
  </script>


<style scoped>
.top-righ-reg {
  position: absolute;
  top: 11px;
  right: 58px;
  
}

.top-righ-reg:hover .bn-reg {
  background-color: #f60c3e;
  color: white;
  cursor: pointer;
}


.bn-reg{
  border: none;
  width: 46px;
  height: 33px;
  font-size: small;
  font-weight: 900;
}
</style>