<template>
      <div class="center">
        <svg class="polygon" width="180" height="180">
          <polygon class="middle" points="34,0 45,0 80,59 23,59 29,47 60,47" />
          <polygon class="dark" points="34,24 39,35 23,59 80,59 74,80 6,70" />
          <polygon class="light" points="0,59 34,0 60,47 49,47 34,24 6,70" />
        </svg>
      </div>
  </template>
  
  <style scoped>

  
  .center {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: #efefef;
    height: 130px; /* 修改容器高度为130px */
    width: 130px; /* 修改容器宽度为130px */
    border-radius: 4px;
    box-shadow: 10px 12px 17px 0 rgba(0, 0, 0, 0.4);
    transition: background-color 0.5s ease-in-out; 
    opacity: 0; /* 初始状态设置为透明 */
    animation: fadeInCenter 2s ease-in-out forwards; /* 添加逐渐显示的动画 */
  }
  
  .center:hover {
    background-color: #343434; /* 鼠标悬停时的背景颜色 */
    cursor: pointer;
}
@keyframes fadeInCenter {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
  }
}


  .polygon {
    position: absolute;
    width: 100px; /* 修改 SVG 宽度为800px */
    height: 70px; /* 修改 SVG 高度为70px */
    top: 30px; /* 修改 SVG 相对容器的上边距为30px */
    left: 25px; /* 修改 SVG 相对容器的左边距为25px */
    .light {
      fill: #aaa;
      opacity: 0; /* 初始状态设置为透明 */
    animation: fadeInCenter 2s ease-in-out forwards; /* 添加逐渐显示的动画 */
      transition: 3s ease-in-out;
    }
    .middle {
      fill: #555;
      opacity: 0; /* 初始状态设置为透明 */
    animation: fadeInCenter 2s ease-in-out forwards; /* 添加逐渐显示的动画 */
      transition: 3s ease-in-out;
    }
    .dark {
      fill: #f60c3e;
      transition: 3s ease-in-out;
    }
  
    &:hover {
      .light {
        fill: #f60c3e;
      }
      .middle {
        fill: #aaa;
      }
      .dark {
        fill: #555;
      }
      cursor: pointer;
      
    }
  }
  </style>