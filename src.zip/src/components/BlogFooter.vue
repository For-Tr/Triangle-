<!--  frontend/src/components/BlogFooter.vue  -->

<template>
    <div class="red-bar-left"></div>
    <div class="red-bar-right"></div>
    <div class="red-bar-top"></div>
    <div class="red-bar"></div>
</template>

<script>
    export default {
        name: 'BlogFooter'
    }
</script>

<style scoped>
    
    .red-bar-top {
        position: fixed;
        top: 0;
        width: 100%;
        height: 11px;
        background-color: #f60c3e;
    }
    .red-bar {
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 11px;
        background-color: #f60c3e;
    }

    .red-bar-right {
        position: fixed;
         top: 0;
  height: 100%;
  width: 11px;
  background-color: #f60c3e;
  right: 0;
}
    

    .red-bar-left {
        position: fixed;
  top: 0;
  height: 100%;
  width: 11px;
  background-color: #f60c3e;
  left: 0;
}
    
</style>