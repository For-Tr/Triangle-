<template>
  <div class="top-righ-log">
    <button @click="showDropdown = !showDropdown" class="bn-log">
      登录
    </button>
    <login-from v-if="showDropdown" @close="showDropdown = false"  class="form"/>
  </div>
</template>

<script>
import { ref } from "vue";
import LoginFrom from "./LoginForm.vue";

export default {
  components: {
    LoginFrom,
  },
  setup() {
    const showDropdown = ref(false);

    return {
      showDropdown,
    };
  },
};
</script>


<style scoped>
.top-righ-log {
  position: absolute;
  top: 11px;
  right: 11px;
}

.top-righ-log:hover .bn-log {
  background-color: #f60c3e;
  color: white;
  cursor: pointer;
}


.bn-log{
  border: none;
  width: 46px;
  height: 33px;
  font-size: small;
  font-weight: 900;
}

.form{
  position: absolute;
  left: -150px;
  top: 164px;

}
</style>