<!--  frontend/src/components/BlogHeader.vue  -->

<template>
    
    <div>

        <search-btn></search-btn>
        
        <div class="login">
            <div v-if="hasLogin">
                <user-btn></user-btn>
            </div>
            <div v-else>
                <reg-btn></reg-btn>
                <login-btn></login-btn>
            </div>
        </div>

       
    </div>  
   
</template>

<script>

    import UserBtn from './UserBtn.vue';
    import SearchBtn from './SearchBtn.vue';
    import LoginBtn from './LoginBtn.vue';
    import RegisterBtn from './RegisterBtn.vue';
    import authorization from '@/utils/authorization';


    export default {
      
        name: 'BlogHeader',
        data: function () {
            return {
                email: '',
                hasLogin: false,
            }
        },
        components: {
            'user-btn': UserBtn,
            'search-btn': SearchBtn,
            'login-btn': LoginBtn,
            'reg-btn': RegisterBtn,
        }, 
        mounted() {
           authorization().then((data) => [this.hasLogin, this.email] = data);
        }
            
     }
        
 
</script>

<style scoped>
 

    .login {
        text-align: right;
        padding-right: 5px;
    }
    
   

</style>