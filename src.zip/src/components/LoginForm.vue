<template>
<div class="box">

  <form>
    <div class="inputBox">
      <input type="email" v-model="email" required onkeyup="this.setAttribute('value', this.value);" >
      <label>E-mail</label>
    </div>
    <div class="inputBox">
      <input type="password" v-model="password" required 
             onkeyup="this.setAttribute('value', this.value);"
             
             title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters">
      <label>密码</label>
    </div>
<button v-on:click.prevent="signin" class="btn">
    立即登录->
</button>
  </form>
</div>
  </template>


<script>
    import axios from 'axios';


    export default {
        name: 'Login',
        data: function () {
            return {
                email: '',
                password: '',
                signupResponse: null,
            }
        },
        methods: {
            signin() {
                const that = this;
                axios
                    .post('/api/token/', {
                        email: that.email,
                        password: that.password,
                    })
                    .then(function (response) {
                        const storage = localStorage;
                        // Date.parse(...) 返回1970年1月1日UTC以来的毫秒数
                        // Token 被设置为1分钟，因此这里加上60000毫秒
                        const expiredTime = Date.parse(response.headers.date) + 60000;
                          // 设置 localStorage
                        storage.setItem('access.myblog', response.data.access);
                        storage.setItem('refresh.myblog', response.data.refresh);
                        storage.setItem('expiredTime.myblog', expiredTime);
                        storage.setItem('email.myblog', that.email);
                        // 路由跳转
                        // 登录成功后回到博客首页
                        that.$router.push({name: 'Home'}).then(() => {  
    location.reload();  
});
                    })
                    // 读者自行补充错误处理
                    // .catch(...)
            },
        }
    }



</script>

  <style scoped>


.box {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 25rem;
  padding: 2.5rem;
  box-sizing: border-box;
  background: rgba(0, 0, 0, 0.65);
  border-radius: 0.625rem;
  z-index: 99;

}

.box h2 {
  margin: 0 0 1.875rem;
  padding: 0;
  color: #fff;
  text-align: center;
}

.box .inputBox {
  position: relative;
}

.box .inputBox input {
  width: 100%;
  padding: 0.625rem 0;
  font-size: 1rem;
  color: #fff;
  letter-spacing: 0.062rem;
  margin-bottom: 1.875rem;
  border: none;
  border-bottom: 0.065rem solid #fff;
  outline: none;
  background: transparent;
}

.box .inputBox label {
  position: absolute;
  top: 0;
  left: 0;
  padding: 0.625rem 0;
  font-size: 1rem;
  color: #fff;
  pointer-events: none;
  transition: 0.5s;
}

.box .inputBox input:focus ~ label,
.box .inputBox input:valid ~ label,
.box .inputBox input:not([value=""]) ~ label {
  top: -1.125rem;
  left: 0;
  color: #c6c6c6;
  font-size: 0.75rem;
}

.btn{
  border: none;
  outline: none;
  color: #fff;
  background-color: #f60c3e;
  padding: 0.625rem 1.25rem;
  cursor: pointer;
  border-radius: 0.312rem;
  font-size: 1rem;
}


.btn:hover {
  background-color: #ef6060;
}



</style>