<template>

<div class="searchBox">
  <input class="searchInput" type="text" name="" placeholder="Search">
    <button class="searchButton" href="#">
      <n-icon color="#272727" size="18">
        <div class="icsearch">
         <search-outline />
        </div>
      </n-icon>
    </button>
  
</div>

</template>
  
  <script>
  import {
    SearchOutline 
  } from "@vicons/ionicons5";
  import {  NIcon} from "naive-ui";

  export default{
    
    components: {
         SearchOutline, NIcon
    }
  };
  </script>


<style scoped>

.searchBox {
    position: absolute;
    top: 11px;
    right: 105px;

    background: #efefef;
    height: 33px;



}

.searchBox:hover > .searchInput {
    width: 120px;
    cursor: text;
}

.searchBox:hover > .searchButton {
  background: #f60c3e;
  color : #f60c3e;
  cursor: pointer;
}

.searchButton {
    color: white;
    float: right;
    border: none;
    top: 10px;
    width: 33px;
    height: 33px;
    background: #efefef;
    justify-content: center;
    align-items: center;

    align-items: center;
    transition: 0.4s;
}

.searchInput {
    border:none;
    background: none;
    outline:none;
    
    color: #272727;
    font-size: 16px;
    transition: 0.4s;
    line-height: 33px;
    width: 0px;

}

@media screen and (max-width: 620px) {
.searchBox:hover > .searchInput {
    width: 150px;
    padding: 0 6px;
}
}

.searchBox:hover  .icsearch{
  color: white;
}
</style>