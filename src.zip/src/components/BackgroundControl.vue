
<template>
    <div>
      <div>
        <button @click="setBackgroundColor('#FFFCF5')">红色</button>
        <button @click="setBackgroundColor('green')">绿色</button>
        <button @click="setBackgroundColor('#000')">蓝色</button>
      </div>
    </div>
  </template>
   
  <script>
  export default {
    data() {
      return {
        backgroundColor: '#FFFCF5',
      };
    },
    methods: {
      setBackgroundColor(color) {
        this.backgroundColor = color;
        document.body.style.backgroundColor = color;
      },
    },
  };
  </script>
