<template>
    <div class="logo">
        <logo></logo>
    </div>
    <div class="mu">

      <div class="mar"></div>
        <div class="main">
          <router-link :to="{ name: 'NoteCreate' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <pen-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="text-with-line">留下诗意</span>
            </n-button>
          </router-link>
        </div>
        <div class="main">
          <router-link :to="{ name: 'Developing' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <blog-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="text-with-line">博客存档</span>
            </n-button>
          </router-link>
        </div>
        <div class="main">
          <router-link :to="{ name: 'Developing' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <logo-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="text-with-line">关于本站</span>
            </n-button>
          </router-link>
        </div>

        <div class="mar"></div>
        <span style="font-size: 10px; color: #f60c3e;  font-weight: bold; padding-left: 28px;">Triangle.Members</span>

        <div class="member">
          <div v-if="hasLogin">
            <router-link :to="{ name: 'Developing' }">
              <n-button text text-color="#272727" class="btn">
                  <n-icon size="16">
                    <mem-icon />
                  </n-icon>
                  &nbsp;&nbsp;<span class="text-with-line">会员中心</span>
              </n-button>
            </router-link>
          </div>
          <div v-else>
            <router-link :to="{ name: 'Register' }">
              <n-button text text-color="#272727" class="btn">
                  <n-icon size="16">
                    <mem-icon />
                  </n-icon>
                  &nbsp;&nbsp;<span class="text-with-line">会员订阅</span>
              </n-button>
            </router-link>
          </div>
        </div>
        <div class="member">
          <router-link :to="{ name: 'Developing' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <ham-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="text-with-line">催更专区</span>
            </n-button>
          </router-link>
        </div>
        
        <div class="mar1"></div>
        <span style="font-size: 10px; color: #f60c3e;  font-weight: bold; padding-left: 28px;">Triangle.Lab</span>

        <div class="lab">
          <router-link :to="{ name: 'NoteList' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <note-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="text-with-line">一些留言</span>
            </n-button>
          </router-link>
        </div>
        <div class="lab">
          <router-link :to="{ name: 'Developing' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <trblog-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="text-with-line">Tr的博客</span>
            </n-button>
          </router-link>
        </div>
        <div class="lab">
          <router-link :to="{ name: 'Developing' }">
            <n-button text text-color="#272727" class="btn">
                <n-icon size="16">
                  <newths-icon />
                </n-icon>
                &nbsp;&nbsp;<span class="longtext-with-line">新奇的玩意儿</span>
            </n-button>
          </router-link>
        </div>
        <div class="lab">
          <router-link :to="{ name: 'Developing' }">
            <n-button text text-color="#272727" class="btn">
                <span style="font-size: 14px;  font-weight: bold;">更多</span>
                <n-icon size="14">
                  <arr-icon />
                </n-icon>
            </n-button>
          </router-link>
        </div>
    </div>
    
  </template>
  
  <script>
  import { NIcon, NButton } from "naive-ui";
  import {
    ReaderOutline as PenIcon,
    FileTrayFullOutline as BlogIcon,
    TriangleOutline as LogoIcon,
    DiamondOutline as MemIcon,
    HammerOutline as HamIcon,
    ArrowForwardSharp as ArrIcon,
    NewspaperOutline as NoteIcon,
    PlanetOutline as TrblogIcon,
    BonfireOutline as NewthsIcon
  } from "@vicons/ionicons5";
  import Logo from "./Logo.vue";
  import authorization from '@/utils/authorization';

  export default {
    components: {
        Logo, NButton, PenIcon, NIcon, BlogIcon, LogoIcon, MemIcon, HamIcon, ArrIcon, NoteIcon, TrblogIcon, NewthsIcon
    },
    data: function () {
            return {
                username: '',
                hasLogin: false,
            }
        },
    mounted() {
       authorization().then((data) => [this.hasLogin, this.username] = data);
    }
  };
  </script>

<style scoped>
.logo{
  position: absolute;
  top: 90px;
  left: 85px;
}
.mu{
    position: absolute;
    top: 200px;
}

.btn{
  position: absolute;
  left: 35px;
}

.mar{
  height: 15px;
}
.mar1{
  height: 25px;
}
.main{
  height: 45px;
}
.member{
  height: 30px;
  padding-top: 15px;
}
.lab{
  height: 30px;
  padding-top: 15px;
}
.text-with-line {
  position: relative;
  display: inline-block;
}
.text-with-line::after {
  content: "";
  position: absolute;
  bottom: 50%;
  left: calc(100% + 3px);
  transform: translateY(50%);
  height: 1px;
  width: calc(100% - 10px);
  border-bottom: 1px dotted #DDDDDD;
}
.text-with-line:hover::after {
  border-color: #f60c3e;
}
.btn:focus .text-with-line {
  font-weight: bold;
}

.btn:focus .text-with-line::after {
  border-bottom: 1px dashed #000;
}
.longtext-with-line {
  position: relative;
  display: inline-block;
}
.longtext-with-line::after {
  content: "";
  position: absolute;
  bottom: 50%;
  left: calc(100% + 3px);
  transform: translateY(50%);
  height: 1px;
  width: calc(100% - 65px);
  border-bottom: 1px dotted #DDDDDD;
}
.longtext-with-line:hover::after {
  border-color: #f60c3e;
}
.btn:focus .longtext-with-line {
  font-weight: bold;
}

.btn:focus .longtext-with-line::after {
  border-bottom: 1px dashed #000;
}

.btn:hover {
  color: #f60c3e;
}
.btn:focus:hover{
  cursor: default;
  
  color: #272727;
}



</style>