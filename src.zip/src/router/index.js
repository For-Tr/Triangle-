// frontend/src/router/index.js

import {createWebHashHistory, createRouter} from "vue-router";
import Home from "@/views/Home.vue";
import NoteDetail from "@/views/NoteDetail.vue";
import Register from "@/views/Register.vue";
import NoteCreate from "@/views/NoteCreate.vue";
import NoteList from "@/views/NoteList.vue";
import Developing from "@/views/Developing.vue";


const routes = [
    {
        path: "/",
        name: "Home",
        component: Home,
    },
    {
        path: "/notes/:id",
        name: "NoteDetail",
        component: NoteDetail,
        
    },
    {
        path: "/members",
        name: "Register",
        component: Register
    },
    {
        path: "/notes/create",
        name: "NoteCreate",
        component: NoteCreate
      },
      {
        path: "/notes",
        name: "NoteList",
        component: NoteList
      },
      {
        path: "/developing",
        name: "Developing",
        component: Developing
      },



];

const router = createRouter({
    history: createWebHashHistory(),
    routes,
});

export default router;